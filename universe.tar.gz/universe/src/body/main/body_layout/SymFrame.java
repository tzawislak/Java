package body.main.body_layout;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.naming.ldap.ControlFactory;
import javax.swing.AbstractButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
//Panel wyswietlajacy symulacje
//Zmieniłem algorytm na velocity Verlet, ale wciąż mam problem ze skalowaniem. 200px == 150mln km
// Prędkość (najprawdopodobniej), albo stała grawitacji(małe szanse) jest źle skalowana.
//Uwaga na krok czasowy, nie jest dowolny!
//Co do kroku czasowego:
import javax.swing.JTextField;

import body.main.languages.Lang;
import body.main.languages.ANG.Angielski;
import body.main.languages.POL.Polski;


//Bład w algorytmie:
//Orbity się rozjeżdżają
public class SymFrame extends JPanel implements Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static PlanetContainer allPlanets;
	public static PlanetContainer tempPlanets;
	public static Boolean isFirstStep=true; 
	public static double[] widok = {0, 0};			//przesuniecie x-y wyswietlanej symulacji
	public static double zoom =2000000000.;			//przybliż-oddal (sterowanie suwakiem)
	public static int SimCenterPlanet = 0;  		//wybierz planetę, z której obserwujemy ruch innych planet	
	public static long SimTimeStep = 51;
	public static Boolean holdOn = false;   //Wstrzymuje symulację
	public static Boolean panelNotClicked = true;
	public final static double dt=60*60*24;	//krok czasowy 1/2 dnia Ziemskiego
	Toolkit toolkit;
	//public int time = 0;

		
	public SymFrame() throws HeadlessException {
		toolkit=Toolkit.getDefaultToolkit();
		this.setBackground(Color.BLACK);
		//Setting default planet Layout
		initializeParams();			
		//end Setting default planet Layout	
	}
	
	public static void initializeParams() {
		try {
		allPlanets = new PlanetContainer();
		tempPlanets = new PlanetContainer();
		
		allPlanets.addPlanet( 0, 0, 0,         1.989E30, 0, 0, 0, ImageIO.read(new File("Slonce.png")));			//Slonce
		allPlanets.addPlanet( 0, 5.791E7, 0, 3.3011E23, 58980, 0, 0, ImageIO.read(new File("Merkury.png")));			//Merkury
		allPlanets.addPlanet( 0, 1.0821E11, 0, 4.867E24, 34784, 0, 0,ImageIO.read(new File("Venus.png")));			//Venus
		allPlanets.addPlanet( 0, 1.496E11, 0,  5.972E24, 29291, 0, 0,ImageIO.read(new File("Ziemia.png")));		//Ziemia 
		allPlanets.addPlanet( 0, 2.279E11, 0,   6.39E23,  21970, 0, 0,ImageIO.read(new File("Mars.png")));		//Mars
		allPlanets.addPlanet( 0, 7.786E11, 0,  1.898E27, 12440, 0, 0,ImageIO.read(new File("Jowisz.png")));			//Jowisz	
		allPlanets.addPlanet( 0, 1.434E12, 0,  5.683E26, 9090, 0, 0,ImageIO.read(new File("Saturn.png")));			//Saturn
		allPlanets.addPlanet( 0, 2.872E12, 0,  8.681E25, 6490, 0, 0,ImageIO.read(new File("Uran.png")));			//Uran
		allPlanets.addPlanet( 0, 4.495E12, 0,  1.024E26, 5370, 0, 0,ImageIO.read(new File("Neptun.png")));			//Neptun
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for( int i=0; i<allPlanets.planety.size(); ++i) { 
			allPlanets.planety.get(i).setSize((int)(10*Math.pow((allPlanets.planety.get(i).getM()/1E23), 0.1)) );
			//System.out.println(allPlanets.planety.get(i).getSize());
		}
		tempPlanets = allPlanets;
	//GUI and Languages
		MainFrame.nameSpace.InitPlanetNames();
		ControlPanel.tP = SymFrame.allPlanets.planety.get( SymFrame.allPlanets.planety.size()-1);
	
		
		
	}
	
	public static void getPlanetInfo(final int number) {
		KeyListener keyListener = new KeyListener() {
		      public void keyPressed(KeyEvent keyEvent) {
		        
		      }

		      public void keyReleased(KeyEvent keyEvent) {
		    	  JTextField textField = (JTextField) keyEvent.getSource();
		          String text = textField.getText();
		      }

		      public void keyTyped(KeyEvent keyEvent) {
		        
		      }
		    };
		ActionListener zoomingListener = new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				AbstractButton abstractButton = (AbstractButton) e.getSource();
		        boolean selected = abstractButton.getModel().isSelected();
		        if (selected == true) {
		        	SimCenterPlanet = number;
		        }
		        else {
		        	SimCenterPlanet = 0;
		        }
			}
		};
		
		JTextField x = new JTextField(Double.toString(SymFrame.allPlanets.planety.get(number).getX()));
	    x.addKeyListener(keyListener);
	    JTextField y = new JTextField(Double.toString(SymFrame.allPlanets.planety.get(number).getY()));
	    y.addKeyListener(keyListener);
	    JTextField mass = new JTextField(Double.toString(SymFrame.allPlanets.planety.get(number).getM()));
	    mass.addKeyListener(keyListener);
	    JTextField vx = new JTextField(Double.toString(SymFrame.allPlanets.planety.get(number).getVX()));
	    vx.addKeyListener(keyListener);
	    JTextField vy = new JTextField(Double.toString(SymFrame.allPlanets.planety.get(number).getVY()));
	    vy.addKeyListener(keyListener);
	    JCheckBox zooming = new JCheckBox();
	    zooming.addActionListener(zoomingListener);
		JPanel initPanel = new JPanel();
		initPanel.setLayout(new GridLayout(7,1));
	
		initPanel.add( new JLabel(MainFrame.nameSpace.gpiX));
		initPanel.add(x);
		initPanel.add( new JLabel(MainFrame.nameSpace.gpiY));
		initPanel.add(y);
		initPanel.add( new JLabel(MainFrame.nameSpace.gpiMass));
		initPanel.add(mass);
		initPanel.add( new JLabel(MainFrame.nameSpace.gpiVx));
		initPanel.add(vx);
		initPanel.add( new JLabel(MainFrame.nameSpace.gpiVy));
		initPanel.add(vy);
		initPanel.add( new JLabel(MainFrame.nameSpace.gpiIsCenter));
		initPanel.add(zooming);
		
		
		int initResult = JOptionPane.showConfirmDialog(null, initPanel, 
				MainFrame.nameSpace.gpiTitle, JOptionPane.OK_CANCEL_OPTION);
	      if (initResult == JOptionPane.OK_OPTION) {
	    	  allPlanets.planety.get(number).setX(Double.parseDouble(x.getText()));
	    	  allPlanets.planety.get(number).setY(Double.parseDouble(y.getText()));
	    	  allPlanets.planety.get(number).setM(Double.parseDouble(mass.getText()));
	    	  allPlanets.planety.get(number).setVX(Double.parseDouble(vx.getText()));
	    	  allPlanets.planety.get(number).setVY(Double.parseDouble(vy.getText()));
	    	  allPlanets.planety.get(number).setSize((int)(10*Math.pow(Double.parseDouble(mass.getText())/1E23, 0.1)) );
	    	  panelNotClicked = true;
	         //System.out.println(" FS: "+fieldStrength+"\n FP: "+ fieldPower);
	      }
	}
	
	private void doDrawing(Graphics g) {
		
        Graphics2D g2d = (Graphics2D) g;

        for (Planeta pl : allPlanets.planety) {
        	pl.paint( g2d);
        }
    }
		
 	public void paintComponent(Graphics g) {
		super.paintComponent(g);
	/*	try {
			g.drawImage(ImageIO.read(new File("stars.png")), 0, 0, this);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		doDrawing(g);
	}

 	public void moveAllPlanets() {
		for( int i=0; i<allPlanets.planety.size(); ++i) {
			double[] f= {0, 0}; //dla każdej planety należy zsumować kontrybucję do składowych siły wypadkowej od wszystkich innych planet
			double r = 0;
			Planeta pi = allPlanets.planety.get(i);
			Planeta temp_pi = allPlanets.planety.get(i);
			for( int j=0; j<allPlanets.planety.size(); ++j) {
				if(i==j) continue;
				// odległości pomiędzy planetami	
				double x = pi.getX() -  allPlanets.planety.get(j).getX();
				double y = pi.getY() -  allPlanets.planety.get(j).getY();
				 r = Math.sqrt(x*x+y*y);//+z*z);
				//siły oddziaływań planet i,j;	
				f[0] += -1*MainFrame.fieldStrength * allPlanets.planety.get(j).getM() * pi.getM() * Math.pow(r, MainFrame.fieldPower-1)*x ;
				f[1] += -1*MainFrame.fieldStrength * allPlanets.planety.get(j).getM() * pi.getM() * Math.pow(r, MainFrame.fieldPower-1)*y ;
				//double fz = SCALE*SCALE*SCALE/1000000000*MainFrame.fieldStrength * allPlanets.planety.get(j).getM() / Math.pow(r, MainFrame.fieldPower+1)*z ;
						
			}

		//x(t+dt):
			temp_pi.setX( pi.getX() + pi.getVX()*dt + 0.5*pi.getFX()*dt*dt/pi.getM());
		//y(t+dt)
			temp_pi.setY( pi.getY() + pi.getVY()*dt + 0.5*pi.getFY()*dt*dt/pi.getM());
		//vx(t+dt)
			temp_pi.setVX( pi.getVX() + 0.5*( f[0] + pi.getFX() )/pi.getM()*dt );
		//vy(t+dt)
			temp_pi.setVY( pi.getVY() + 0.5*( f[1] + pi.getFY() )/pi.getM()*dt );
		//fx(t+dt)
			temp_pi.setFX(f[0]);
		//fy(t+dt)
			temp_pi.setFY(f[1]); 
		//if(i==1)	System.out.println("Planeta: id: "+MainFrame.fieldStrength+",\t x= "+r+",\t y= "+pi.getM()); 
		if(i==1) {	
		//	System.out.println("x= "+pi.getX()+" "+pi.getY()+" "); 
		//	System.out.println("x1= "+pi.getX()+" "+i+" "); 
			//System.out.println("y1= "+pi.getY()+" "+i+" \n");
			
		}	
		}
	}
	
	public void initialMoveAllPlanets() {

		for( int i=0; i<allPlanets.planety.size(); ++i) {
			double[] f= {0, 0}; 
			for( int j=0; j<allPlanets.planety.size(); ++j) {
				if(i==j) continue;
				// odległości pomiędzy planetami	
				double x = allPlanets.planety.get(i).getX() -  allPlanets.planety.get(j).getX();
				double y = allPlanets.planety.get(i).getY() -  allPlanets.planety.get(j).getY();
				//double z = allPlanets.planety.get(i).getZ() -  allPlanets.planety.get(j).getZ();
				double r = Math.sqrt(x*x+y*y);//+z*z);
				//siły  oddziaływań planet i,j;	
				f[0] += -1*MainFrame.fieldStrength * allPlanets.planety.get(j).getM()*allPlanets.planety.get(i).getM() * Math.pow(r, MainFrame.fieldPower-1)*x ;
				f[1] += -1*MainFrame.fieldStrength * allPlanets.planety.get(j).getM()*allPlanets.planety.get(i).getM() * Math.pow(r, MainFrame.fieldPower-1)*y ;
				//double fz = SCALE*SCALE*SCALE/1000000000*MainFrame.fieldStrength * allPlanets.planety.get(j).getM() / Math.pow(r, MainFrame.fieldPower+1)*z ;
							
			}	
			allPlanets.planety.get(i).setFX(f[0]);
			allPlanets.planety.get(i).setFY(f[1]);
			//System.out.println("Start: id: "+MainFrame.fieldStrength+",\t x= "+allPlanets.planety.get(i).getX()+",\t y= "+allPlanets.planety.get(i).getY()); 

		}	
	}
	
	public void holdOnASecond() {
		try {
			TimeUnit.MILLISECONDS.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		
	
		while( true ) {
				
			if (panelNotClicked) {
				widok[0] = MainFrame.symFrameSize[0]/2-allPlanets.planety.get(SimCenterPlanet).getX()/zoom; 
				widok[1] = MainFrame.symFrameSize[1]/2-allPlanets.planety.get(SimCenterPlanet).getY()/zoom;
			}
			else {
				widok[0] = -allPlanets.planety.get(SimCenterPlanet).getX()/zoom+MainFrame.ClickMV[0];
				widok[1] = -allPlanets.planety.get(SimCenterPlanet).getY()/zoom+MainFrame.ClickMV[1];
			}
			//In Verlet it is neccesary to have two initial spatial coordinates, so first step is to calculate "initial first displacement" from Euler:
			if(isFirstStep) {
				initialMoveAllPlanets();
				isFirstStep=false;
			}
			moveAllPlanets();
			allPlanets = tempPlanets;// przypisuje nowe pozycje
			repaint();
			toolkit.sync();
			try {
				TimeUnit.MILLISECONDS.sleep(SimTimeStep);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			while(holdOn) {	holdOnASecond(); }
			
		}
	}

	
	
		
	

}

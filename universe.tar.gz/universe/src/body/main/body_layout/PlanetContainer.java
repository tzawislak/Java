package body.main.body_layout;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

public class PlanetContainer {
	List<Planeta> planety;
	
	public PlanetContainer() {
		planety = new ArrayList<Planeta>();
		
	}
	
	public void addPlanet(double _x, double _y, double _z, double _m, double _vx, double _vy, double _vz, BufferedImage _img) {
		planety.add( new Planeta( _x, _y, _z, _m, _vx, _vy, _vz, _img ));
	}

}

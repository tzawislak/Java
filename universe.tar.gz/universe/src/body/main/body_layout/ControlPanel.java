package body.main.body_layout;
import body.main.languages.*;
import java.awt.BorderLayout;



import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.*;

import body.main.languages.Lang;
import body.main.languages.ANG.Angielski;
import body.main.languages.POL.Polski;

public class ControlPanel extends JPanel implements ActionListener, Runnable
{
	static final int SLIDER_MIN = 1;
	static final int SLIDER_MAX = 100;
	static final int SLIDER_INIT = 20;
	static final int SLIDER_INIT1 = 1;
	public Boolean czyWstrzymac = true;
	public static Boolean czyPierwszyRaz = true;
	public static Planeta tP;
	public static JPanel panel1;
	public JPanel panel2;
	public JPanel panel3;
	public JPanel panel4;
	public JPanel panel5;
	public JPanel sliderPanel;
	public JPanel sliderPanel1;
	static double time = 0;
	List<BufferedImage> planetyPics = new ArrayList<BufferedImage>();
	
	JSlider zoom, timeStepSlider;
	public JLabel zoomSlider, timeSlider, symTime, rocketTime, symTimeBox, rocketTimeBox, sliderValue;
	Timer timer;
	//JRadioButton r1, rButton2;
	//ButtonGroup group;
	public static List<JButton> planets = new ArrayList<JButton>();
	JButton changeParameters, reSymulate, dodajPlanete, pause;
	JTextField symTimer, rocketTimer;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public ControlPanel() 
	{
		this.setBackground(Color.black);
		this.setLayout(new GridLayout(5,1));
		try {
			planetyPics.add(ImageIO.read(new File("planet1.png")));
			planetyPics.add(ImageIO.read(new File("planet2.png")));
			planetyPics.add(ImageIO.read(new File("planet3.png")));
			planetyPics.add(ImageIO.read(new File("planet4.png")));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
		panel4 = new JPanel();
		panel5 = new JPanel();
		sliderPanel = new JPanel();
		sliderPanel1 = new JPanel();
		
		Lang currentLanguage = new Polski();
		if(MainFrame.ProgLanguage == 1) currentLanguage = new Angielski();
		
		panel1.setLayout(new GridLayout(3,2));
		InitJButtons();
		for( int i=0; i<planets.size(); i++) {
			planets.get(i).addActionListener(changePlanetParametersActionListener); 
			panel1.add(planets.get(i));
		}
		
		symTime = new JLabel(currentLanguage.symTimerName);
		symTimeBox = new JLabel("0 h");
		
		panel2.add(symTime);
		panel2.add(symTimeBox);
		
		zoomSlider = new JLabel(currentLanguage.zoomSliderName);
		zoom = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN, SLIDER_MAX, SLIDER_INIT);
		zoom.setPaintTicks(true);
		sliderValue = new JLabel(Integer.toString(zoom.getValue()));
		zoom.addChangeListener(new ChangeListener() {
		      public void stateChanged(ChangeEvent event) {
		        int value =  zoom.getValue();
		        sliderValue.setText(Integer.toString(value));
		        SymFrame.zoom = Math.pow(value, 1.5)*100000000.; 		     
		      }
		    });
		panel3.setLayout(new BorderLayout());
		sliderPanel.setLayout(new FlowLayout());
		sliderPanel.add(zoomSlider);
		sliderPanel.add(sliderValue);
		panel3.add(zoom, BorderLayout.CENTER);
		panel3.add(sliderPanel, BorderLayout.PAGE_START);
		timeSlider = new JLabel(currentLanguage.timeSliderName);
		timeStepSlider = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN, 50, SLIDER_INIT1);
		timeStepSlider.addChangeListener(new ChangeListener() {
		      public void stateChanged(ChangeEvent event) {
		        long value = timeStepSlider.getValue();
		        SymFrame.SimTimeStep  = 51-value;                         ///sensowniej by było odwrócić                 
		      }
		 });
		sliderPanel1.setLayout(new FlowLayout());
		sliderPanel1.add(timeSlider);
		//sliderPanel1.add(sliderValue);
		panel4.setLayout(new BorderLayout());
		panel4.add(timeStepSlider, BorderLayout.CENTER);
		panel4.add(sliderPanel1, BorderLayout.PAGE_START);
		
		//rocketTime = new JLabel(currentLanguage.rocketTimerName);
		//rocketTimeBox = new JLabel("00:00:00");
		//panel4.add(rocketTime);
		//panel4.add(rocketTimeBox);
		
		changeParameters = new JButton(currentLanguage.changeParametersButtonName);
		changeParameters.addActionListener(changeParametersActionListener);
		reSymulate = new JButton(currentLanguage.reSymulateButtonName);
		reSymulate.addActionListener(resymulateButtonListener);
		dodajPlanete = new JButton(currentLanguage.dodajPlaneteName);
		dodajPlanete.addActionListener(dodajPlaneteButtonListener);
		pause = new JButton(currentLanguage.pauseName);
		pause.addActionListener(pauseButtonListener);
		panel5.setLayout(new GridLayout(2,2));
		panel5.add(changeParameters);
		panel5.add(reSymulate);
		panel5.add(dodajPlanete);
		panel5.add(pause);
		
		
		//changeParameters.imageUpdate(img, infoflags, x, y, w, h)
		
		this.add(panel5);
		this.add(panel2);
		this.add(panel3);
		this.add(panel4);
		this.add(panel1);
		
		this.setBackground(Color.black);
	}
	
	public static void InitJButtons() {
		//pierwsza inicjalizacja
		planets = new ArrayList<JButton>();
		for(int k=0; k<MainFrame.nameSpace.planetNames.size(); k++) {
			planets.add(new JButton(MainFrame.nameSpace.planetNames.get(k)));
		}
		
		//Każda kolejna inicjalizacja
		if(!czyPierwszyRaz) {
			//usuwanie starego panelu z przyciskami planet
			MainFrame.controlPanel.remove(panel1);
			panel1 = new JPanel();
			int sizeG = (int) Math.ceil(Math.sqrt(planets.size()));
			panel1.setLayout(new GridLayout(sizeG, sizeG ));
			//inicjalizacja nowego panelu z przyciskami
			for( int i=0; i<planets.size(); i++) {
				planets.get(i).addActionListener(changePlanetParametersActionListener); 
				panel1.add(planets.get(i));
			}
			
			MainFrame.controlPanel.add(panel1);
			MainFrame.controlPanel.setVisible(false);
			MainFrame.controlPanel.setVisible(true);
			
		}
		czyPierwszyRaz=false;
		
		
	}
	
	ActionListener changeParametersActionListener = new ActionListener() 
	{
		public void actionPerformed(ActionEvent e) 
		{
			SymFrame.holdOn = true;
			MainFrame.getParameters();
			SymFrame.isFirstStep=true;
			SymFrame.holdOn = false;
		}
	};
	
	static ActionListener changePlanetParametersActionListener = new ActionListener() 
	{
		public void actionPerformed(ActionEvent e) 
		{
			SymFrame.holdOn = true;
			String s = e.getActionCommand();
			
			System.out.println(s);
			for( int n=0; n<planets.size(); n++){
				if( planets.get(n).getText().equals(s)) {
					SymFrame.getPlanetInfo(n); 
				}
			}
			
		//	System.out.println(n);                                 ///powyższe żeby sprawdzić czy jest wszystko ok
			SymFrame.isFirstStep=true;
			SymFrame.holdOn = false;
		}
	};
	
	ActionListener resymulateButtonListener = new ActionListener() 
	{
		public void actionPerformed(ActionEvent e) 
		{
			SymFrame.holdOn = true;
			SymFrame.initializeParams();
			ControlPanel.InitJButtons();
			SymFrame.isFirstStep=true;
			SymFrame.holdOn = false;
		}
	};
	
	ActionListener dodajPlaneteButtonListener = new ActionListener() 
	{
		public void actionPerformed(ActionEvent e) 
		{
			SymFrame.holdOn = true;
			String[] LSbuttons = {MainFrame.nameSpace.addPlanet , MainFrame.nameSpace.removePlanet };
			
		    int odpowiedz = JOptionPane.showOptionDialog(null, "", "", JOptionPane.PLAIN_MESSAGE,  JOptionPane.PLAIN_MESSAGE, null, LSbuttons, LSbuttons[1]);
		   //Remove planet 		    
		    if(odpowiedz==1) {
		    	JPanel panelPrzyciskany = new JPanel();
		    	List<JCheckBox> rmPlanets = new ArrayList<JCheckBox>();
				for( int i=0; i<SymFrame.allPlanets.planety.size(); ++i) {
				    rmPlanets.add(new JCheckBox(MainFrame.nameSpace.planetNames.get(i)));
				    rmPlanets.get(i).setSelected(false);
				    panelPrzyciskany.add(rmPlanets.get(i));
				}
									
				JOptionPane.showConfirmDialog(null, panelPrzyciskany, MainFrame.nameSpace.remove+": " , JOptionPane.OK_CANCEL_OPTION);
				int u=0; // usunieto (wazne gdy zaznaczono wiecej niz jedna planetę, bo wtedy przesuwa się index)
				for( int j=0; j< rmPlanets.size(); j++) {
					if(rmPlanets.get(j).isSelected()) {
						//SymFrame.allPlanets.planety.remove(j);
						if(SymFrame.SimCenterPlanet==j-u) {
							SymFrame.SimCenterPlanet = 1;
							
						}
					//Co ma się zdarzyc po zaznaczeniu planet do usuniecia:
						tP = SymFrame.allPlanets.planety.get(j-u);
						SymFrame.allPlanets.planety.remove(j-u);
						//SymFrame.tempPlanets.planety.remove(j);		
						Lang.planetNames.remove(j-u);
					//	planets.get(j-u).setText(" ");
						planets.remove(j-u);
						u++;
						
					}
				}
				//panel1 = new JPanel();
			//	panel1.setLayout(new GridLayout(3,3));
				//for(int k=0; k<planets.size(); k++){
				//	panel1.add(planets.get(k));
					//System.out.println(planets.get(k).getText());
			//	}
				InitJButtons();
				SymFrame.isFirstStep=true;
				
		    }
		    //Add planet
		    if(odpowiedz==0) {
		    	//Kreacja panelu addycji planety
		    	JPanel panelDodaj = new JPanel();
		    	panelDodaj.setLayout(new GridLayout(10, 1));
		    	List<JTextField> jtfP = new ArrayList<JTextField>();
		    	List<JLabel> jlP = new ArrayList<JLabel>();
		    	jlP.add(new JLabel(MainFrame.nameSpace.plName));
		    	jlP.add(new JLabel(MainFrame.nameSpace.gpiMass));
		    	jlP.add(new JLabel(MainFrame.nameSpace.gpiX));
		    	jlP.add(new JLabel(MainFrame.nameSpace.gpiY));
		    	jlP.add(new JLabel(MainFrame.nameSpace.gpiZ));
		    	jlP.add(new JLabel(MainFrame.nameSpace.gpiVx));
		    	jlP.add(new JLabel(MainFrame.nameSpace.gpiVy));
		    	jlP.add(new JLabel(MainFrame.nameSpace.gpiVz));
		    
		    	
		    	jtfP.add(new JTextField());
		    	jtfP.add(new JTextField(Double.toString(tP.getM())));
		    	jtfP.add(new JTextField(Double.toString(tP.getX())));
		    	jtfP.add(new JTextField(Double.toString(tP.getY())));
		    	jtfP.add(new JTextField(Double.toString(tP.getZ())));
		    	jtfP.add(new JTextField(Double.toString(tP.getVX())));
		    	jtfP.add(new JTextField(Double.toString(tP.getVY())));
		    	jtfP.add(new JTextField(Double.toString(tP.getVZ())));
		    	
		    	for( int i=0; i< jlP.size(); i++) {
		    		
		    		panelDodaj.add(jlP.get(i));
		    		panelDodaj.add(jtfP.get(i));
		    	}
		    	//wyswietlanie okna 
		    	int retVal = JOptionPane.showConfirmDialog(null, panelDodaj, MainFrame.nameSpace.remove+": " , JOptionPane.OK_CANCEL_OPTION);
		    	if(retVal==0) {
		    		MainFrame.nameSpace.planetNames.add(jtfP.get(0).getText());
		    		planets.add(new JButton(jtfP.get(0).getText()));
		    		InitJButtons();
		    		SymFrame.isFirstStep=true;
		    		try {
						SymFrame.allPlanets.addPlanet(
								Double.parseDouble(jtfP.get(2).getText()),
								Double.parseDouble(jtfP.get(3).getText()),
								Double.parseDouble(jtfP.get(4).getText()),
								Double.parseDouble(jtfP.get(1).getText()),
								Double.parseDouble(jtfP.get(5).getText()),
								Double.parseDouble(jtfP.get(6).getText()),
								Double.parseDouble(jtfP.get(7).getText()),
								planetyPics.get(SymFrame.allPlanets.planety.size()%4)
								);
						SymFrame.allPlanets.planety.get(SymFrame.allPlanets.planety.size()-1).setSize((int)(10*Math.pow((Double.parseDouble(jtfP.get(1).getText())/1E23), 0.1)) );
						
					} catch (NumberFormatException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		    	}
		    	
		    }
		     
		    
		    SymFrame.holdOn = false;
		}
	};
	
	ActionListener pauseButtonListener = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(czyWstrzymac) {
				SymFrame.holdOn = true;
				czyWstrzymac=false;
			}else {
				SymFrame.holdOn = false;
				czyWstrzymac=true;
			}
		}
	};


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public void holdOnASecond() {
		try {
			TimeUnit.MILLISECONDS.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		while( true) {
			
			time += SymFrame.dt;
			symTimeBox.setText( Double.toString(time/(60.0*60.0*24.0)) + " days");
			
			if(SymFrame.isFirstStep) {
				time = 0;
			}
			
			try {
				TimeUnit.MILLISECONDS.sleep(SymFrame.SimTimeStep);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			while(SymFrame.holdOn) { holdOnASecond(); }
		}
	}



}

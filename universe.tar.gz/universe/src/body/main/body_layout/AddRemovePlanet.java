package body.main.body_layout;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

public class AddRemovePlanet extends JOptionPane {

	public AddRemovePlanet() {
		// TODO Auto-generated constructor stub	
		this.setSize(400,300);
		this.setLayout(new BorderLayout());
		JButton b1 = new JButton(MainFrame.nameSpace.addPlanet);
		JButton b2 = new JButton(MainFrame.nameSpace.removePlanet);
		JPanel centerJP = new JPanel();
		centerJP.setLayout(new FlowLayout());
		
		b1.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				//dodac panel 
			}});
		b2.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				RemovePlanetPanel rpp = new RemovePlanetPanel();
				rpp.setVisible(true);
			}});
		
		centerJP.add(b1);
		centerJP.add(b2);

		this.add(centerJP, BorderLayout.CENTER);
		this.setVisible(true);
	}
	
	//Panel wyswietlany po wybraniu przycisku usun
	public class RemovePlanetPanel extends JOptionPane{

	    public RemovePlanetPanel(){
	    	this.setSize(400,300);
			this.setLayout(new FlowLayout());
			List<JCheckBox> rmPlanets = new ArrayList<JCheckBox>();
			for( int i=0; i<SymFrame.allPlanets.planety.size(); ++i) {
			    rmPlanets.add(new JCheckBox(MainFrame.nameSpace.planetNames.get(i)));
			    rmPlanets.get(i).setSelected(false);
			    this.add(rmPlanets.get(i));
			}
			
			JButton usun = new JButton(MainFrame.nameSpace.remove);
			JButton cancel = new JButton(MainFrame.nameSpace.cancel);
			
			usun.addActionListener(new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
				}});
			cancel.addActionListener(new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent arg0) {
					
				}});
			this.setVisible(true);
			
			
		}
		
		
	}
	

}






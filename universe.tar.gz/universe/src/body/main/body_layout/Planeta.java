package body.main.body_layout;

import java.awt.Color;
import java.awt.Graphics;
import  java.awt.image.BufferedImage;

public class Planeta {
	//trzecia skladowa istnieje, ale na razie nie używam
	
	private double m=5.972E24; //Masa Ziemi w kg
	private double x=0;
	private double y=0;
	private double z=0;
	private double x0=0;
	private double y0=0;
	private double z0=0;
	private double vx=0;
	private double vy=0;
	private double vz=0;
	private double fx=0;
	private double fy=0;
	private double fz=0;
	private int size=10;
	private BufferedImage obraz = null;
	private Color color = Color.BLACK; //as for now. MOdify it so that instead of circles there are images.
	public Planeta(double _x, double _y, double _z, double _m, double _vx, double _vy, double _vz, BufferedImage _img) {
		x=_x;	 
		y=_y;	
		z=_z;
		x0=_x;	 
		y0=_y;	
		z0=_z;
		vx=_vx;
		vy=_vy;
		vz=_vz;
		z=_z;	
		m=_m;
		obraz = _img;
	}
	public void setM(double _m) {	m=_m; }
	public void setX(double _x) { 	x=_x; }
	public void setY(double _y) { 	y=_y; }
	public void setZ(double _z) { 	z=_z; }
	public void setX0(double _x) { 	x0=_x; }
	public void setY0(double _y) { 	y0=_y; }
	public void setZ0(double _z) { 	z0=_z; }
	public void setVX(double _vx) { 	vx=_vx; }
	public void setVY(double _vy) { 	vy=_vy; }
	public void setVZ(double _vz) { 	vz=_vz; }
	public void setFX(double _fx) { 	fx=_fx; }
	public void setFY(double _fy) { 	fy=_fy; }
	public void setFZ(double _fz) { 	fz=_fz; }
	public void setSize(int _size) { size=_size;}

	public double getM() { return m; }
	public double getX() { return x; }
	public double getY() { return y; }
	public double getZ() { return z; }
	public double getX0() { return x0; }
	public double getY0() { return y0; }
	public double getZ0() { return z0; }
	public double getVX() { return vx; }
	public double getVY() { return vy; }
	public double getVZ() { return vz; }
	public double getFX() { return fx; }
	public double getFY() { return fy; }
	public double getFZ() { return fz; }	
	public int getSize() {return size;}
	
	
	public void paint(Graphics g){
       
        double SizeScale = Math.pow(2000000000/SymFrame.zoom, 0.1);
        g.drawImage(
        		obraz,
        		(int) (x/(SymFrame.zoom)+SymFrame.widok[0]-size/2*SizeScale),
        		(int) (y/(SymFrame.zoom)+SymFrame.widok[1]-size/2*SizeScale),
        		(int) (size*SizeScale),
        		(int) (size*SizeScale), null);
        
        
        
        
        
       
        //g.fillOval( (int) (x/(SymFrame.zoom)+SymFrame.widok[0]-size/2*SizeScale),    (int) (y/SymFrame.zoom+SymFrame.widok[1]-size/2*SizeScale),    (int) (size*SizeScale),    (int) (size*SizeScale));
    }

}

package body.main.body_layout;

import body.main.languages.ANG.*;
import javax.swing.event.*;


import body.main.languages.POL.*;
import body.main.languages.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.*;

import javax.swing.JFrame;


public class MainFrame extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static int ProgLanguage = 0; //0 = polski, 1 = angielski
	public static double fieldStrength=6.67E-11;	// parametry pola grawitacyjnego
	public static double fieldPower=-2.0;			// wykładnik r we wzorze na natężenie pola.
	public static Lang nameSpace= new Polski();
	public static SymFrame symFrame;
	public static double[] symFrameSize = {0, 0};
	public static double[] ClickMV = {0, 0};
	public static ControlPanel controlPanel;
	public MainFrame() throws HeadlessException {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		//this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(1000,500);
		

	//Layout 
		this.setLayout(new GridBagLayout());
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.BOTH;
	    gbc.anchor = GridBagConstraints.WEST;
		gbc.weightx = 80;	//zawsze szerokosc Symulacji : szerokosc ControlPanel == 4:1
		gbc.weighty = 100;
		symFrame = new SymFrame();
		symFrame.addComponentListener(new ResizeListener());
		symFrame.addMouseListener(MousePositionListener);
		
		this.add(symFrame, gbc);
		
		controlPanel = new ControlPanel();
		gbc.fill = GridBagConstraints.BOTH;
		gbc.anchor = GridBagConstraints.SOUTH;
		gbc.weightx = 2;
		gbc.weighty = 100;
		this.add(controlPanel, gbc);
	//end Layout 
	
		
	//Menu 	
		JMenuBar menuHead = new JMenuBar();
		//Opcje na pasku górnym:
			JMenu jmMenu = new JMenu(nameSpace.menuName);
				//Opcje w "Menu":
				JMenuItem jmMenuExit = new JMenuItem(nameSpace.menuExit);
		
				jmMenuExit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, ActionEvent.CTRL_MASK));
				jmMenuExit.addActionListener(new ActionListener(){
						@Override
						public void actionPerformed(ActionEvent arg0) {
							System.exit(0);
						}});
				jmMenu.add(jmMenuExit);
				
			JMenu jmEdit = new JMenu(nameSpace.menuEdit);
				JMenuItem jmSaveImage = new JMenuItem(nameSpace.saveImage);
				jmEdit.add(jmSaveImage);
			JMenu jmOptions = new JMenu(nameSpace.menuOptions);
				JMenuItem jmElonMode = new JMenuItem(nameSpace.elonMode);
				jmElonMode.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
						System.exit(0);
					}
				});
				jmOptions.add(jmElonMode);
		
		menuHead.add(jmMenu);
		menuHead.add(jmEdit);
		menuHead.add(jmOptions);
		this.setJMenuBar(menuHead);
	//end Menu
		
	}
	
	public static void getParameters() {                                ////wydaje mi się że ta funkcja pierwotnie była nie do tego 
		KeyListener keyListener = new KeyListener() {
		      public void keyPressed(KeyEvent keyEvent) {
		        
		      }

		      public void keyReleased(KeyEvent keyEvent) {
		    	  JTextField textField = (JTextField) keyEvent.getSource();
		          String text = textField.getText();
		          
		      }

		      public void keyTyped(KeyEvent keyEvent) {
		        
		      }
		    };
		
		JTextField constantJTF = new JTextField("6.6740831E-11");
	    constantJTF.addKeyListener(keyListener);
		JTextField powerJTF = new JTextField("-2");
		powerJTF.addKeyListener(keyListener);
		JPanel initPanel = new JPanel();
		initPanel.add( new JLabel(nameSpace.gipConstant));
		initPanel.add( constantJTF);
		initPanel.add( new JLabel(nameSpace.gipPower));
		initPanel.add( powerJTF);
		
		
		int initResult = JOptionPane.showConfirmDialog(null, initPanel, 
	               nameSpace.gipTitle, JOptionPane.OK_CANCEL_OPTION);
	      if (initResult == JOptionPane.OK_OPTION) {
	         fieldStrength = Double.parseDouble(constantJTF.getText());
	         fieldPower = Double.parseDouble(powerJTF.getText());
	         System.out.println(" FS: "+fieldStrength+"\n FP: "+ fieldPower);
	      }else {
	    	  System.exit(0);
	      }
	}

	

	
	class ResizeListener extends ComponentAdapter {
        public void componentResized(ComponentEvent e) {
           symFrameSize[0] = e.getComponent().getWidth();
           symFrameSize[1] = e.getComponent().getHeight();
           //System.out.println("New dimension: "+symFrameSize[0]+", "+symFrameSize[1]);
        }
	}
	
	MouseListener MousePositionListener = new MouseListener() {

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			/*if (e.getPoint().x < (e.getComponent().getWidth()/2)) {
				symFrameSize[0] = e.getComponent().getWidth() + e.getPoint().x;
			}
			else {
				symFrameSize[0] =  e.getPoint().x;
			}
			if (e.getPoint().y < (e.getComponent().getHeight()/2)) {
				symFrameSize[1] = e.getComponent().getHeight() + e.getPoint().y;
			}
			else {
				symFrameSize[1] =  e.getPoint().y;
			}
			*/
			ClickMV[0]= e.getPoint().x;
			ClickMV[1]= e.getPoint().y;
			SymFrame.panelNotClicked = false;
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	};
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	

	public static void main(String[] args) {
		String[] LSbuttons = { "Polski", "English" };
		
	    ProgLanguage = JOptionPane.showOptionDialog(null, "Select Language:", "Welcome",
	        JOptionPane.PLAIN_MESSAGE, JOptionPane.PLAIN_MESSAGE, null, LSbuttons, LSbuttons[1]);
	  //Language	
	  	if( ProgLanguage == 1) nameSpace = new Angielski();
	  //end Language 	
	    getParameters();
	    MainFrame mainFrame = new MainFrame();
		mainFrame.setVisible(true);
		
		ExecutorService exec = Executors.newFixedThreadPool(2);
		exec.execute(symFrame);
		exec.execute(controlPanel); //zmien
		
		//Thread simThread = new Thread(symFrame); 
		//simThread.start();		//simulation begins

	}
	

}

package body.main.languages.ANG;
import java.util.ArrayList;

import body.main.languages.*;
//za kazdym razem gdy chcesz dodac nazwe utwórz zmienna o tej samie nazwie w Lang.java
//angielski.java i polski.java zawierają definicje kazdej zmiennej;
public class Angielski extends Lang {

	public Angielski() {
	//menu
		super.menuName = "Menu";
		super.menuExit = "Exit";
		super.menuEdit = "Edit";
		super.menuOptions = "Options";
		super.saveImage = "Save image";
		super.elonMode = "Elon mode";
	//getInitialParameters()
		super.gipTitle = "Set Parameters";
		super.gipConstant = "G Constant: ";
		super.gipPower = "Power of r";
	//getPlanetInfo()
		super.gpiTitle = "Set Planet Parameters";
		super.gpiX = "x position";
		super.gpiY = "y position";
		super.gpiZ = "z position";
		super.gpiMass = "mass";
		super.gpiVx = "Vx value";
		super.gpiVy = "Vy value";
		super.gpiVz = "Vz value";
		super.gpiIsCenter = "Show in the center";
	//ControlPanel	
	//Add/Remove panel
		super.addPlanet = "Add planet";
		super.plName = "Name";
		super.removePlanet = "Remove planet";
		super.remove = "Remove";
		super.cancel = "Cancel";
		
		super.symTimerName = "Simulation Time:";
		super.rocketTimerName = "Rocket Flight Time:";
		super.zoomSliderName = "Change Zoom:";
		super.timeSliderName = "Change Simulation Speed";
		super.changeParametersButtonName = "Change Parameters";
		super.reSymulateButtonName = "Resimulate";
		super.dodajPlaneteName = "Add/Remove planet";
		super.pauseName = "Pause/Start";
	}
	
	public void InitPlanetNames() {
		planetNames =  new ArrayList<String>();
		planetNames.add("Sun");
		planetNames.add("Mercury");
		planetNames.add("Venus");
		planetNames.add("Earth");
		planetNames.add("Mars");
		planetNames.add("Jupiter");
		planetNames.add("Saturn");
		planetNames.add("Uranus");
		planetNames.add("Neptun");
	}
}

package body.main.languages;

import java.util.ArrayList;
import java.util.List;

import body.main.body_layout.Planeta;

public abstract class Lang {
//menu 
	public String menuExit;
	public String menuName;
	public String menuEdit, menuOptions;
//getInitialParameters()
	public String gipConstant;
	public String gipPower;
	public String gipTitle;
//getPlanetInfo()
	public String gpiTitle;
	public String gpiX;
	public String gpiY;
	public String gpiZ;
	public String gpiMass;
	public String gpiVx;
	public String gpiVy;
	public String gpiVz;
	public String gpiIsCenter;
//ControlPanel
	public String saveImage, elonMode;
	public static List<String> planetNames;
	public String symTimerName, rocketTimerName, zoomSliderName, timeSliderName, changeParametersButtonName, reSymulateButtonName, dodajPlaneteName, pauseName;;
//Add/Remove panel
	public String plName;
	public String addPlanet;
	public String removePlanet;
	public String remove, cancel;
	//Aby dodać kolejny napis stworz dla niego zmienna i zdefiniuj w klasach Angielski.java i Polski.java
	public abstract void InitPlanetNames();
	public Lang() {	}
}

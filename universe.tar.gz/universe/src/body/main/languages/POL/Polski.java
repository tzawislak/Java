package body.main.languages.POL;
import java.util.ArrayList;

import body.main.languages.*;
//za kazdym razem gdy chcesz dodac nazwe utwórz zmienna o tej samie nazwie w
//angielski.java i polski.java;
public class Polski extends Lang {

	public Polski() {
	//menu	
		super.menuName = "Menu";
		super.menuExit = "Wyjdź";
		super.menuEdit = "Edycja";
		super.menuOptions = "Opcje";
		super.saveImage = "Zapisz grafikę";
		super.elonMode = "Elon mode";
	//getInitialParameters()
		super.gipTitle = "Ustaw parametry pola";
		super.gipConstant = "Stała G: ";
		super.gipPower = "Potęga r";
	//getPlanetInfo()
		super.gpiTitle = "Ustaw Parametry Planety";
		super.gpiX = "współrzędna x";
		super.gpiY = "współrzędna y";
		super.gpiZ = "współrzędna z";
		super.gpiMass = "masa";
		super.gpiVx = "wartość Vx";
		super.gpiVy = "wartość Vy";
		super.gpiVz = "wartość Vz";
		super.gpiIsCenter = "Wyświetl w centrum";
	//ControlPanel	
		
	//Add/Remove panel
		super.plName= "Nazwa";
		super.addPlanet = "Dodaj planetę";
		super.removePlanet = "Usuń planetę";
		super.remove = "Usuń";
		super.cancel = "Cancel";
		
		super.symTimerName = "Czas Symulacji:";
		super.rocketTimerName = "Czas Lotu Rakiety:";
		super.zoomSliderName = "Przybliż/Oddal:";
		super.timeSliderName = "Zmień Tempo Symulacji";
		super.changeParametersButtonName = "Zmień Parametry";
		super.reSymulateButtonName = "Resymuluj";
		super.dodajPlaneteName = "Dodaj/Usuń planetę";
		super.pauseName = "Pauza/Start";
	}
	
	public void InitPlanetNames() {
		planetNames =  new ArrayList<String>();
		planetNames.add("Słońce");
		planetNames.add("Merkury");
		planetNames.add("Wenus");
		planetNames.add("Ziemia");
		planetNames.add("Mars");
		planetNames.add("Jowisz");
		planetNames.add("Saturn");
		planetNames.add("Uran");
		planetNames.add("Neptun");
	}

}
